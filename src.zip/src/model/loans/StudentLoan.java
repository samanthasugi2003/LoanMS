package src.model.loans;

import src.service.LoanManager;

/**
 * StudentLoan class represents a student/education loan product.
 * Extends LoanManager with student loan specific attributes and behavior.
 */
public class StudentLoan extends LoanManager {

    private String universityName;
    private String courseOfStudy;

    /**
     * Constructor for StudentLoan
     */
    public StudentLoan(String loanId, double amount, double rate, int duration,
                       String officer, String branch, String universityName) {
        super(loanId, "STUDENT", amount, rate, duration, "PENDING", officer, branch);
        this.universityName = universityName;
        this.courseOfStudy = "General";
    }

    /**
     * Overloaded constructor with course of study
     */
    public StudentLoan(String loanId, double amount, double rate, int duration,
                       String officer, String branch, String universityName, String courseOfStudy) {
        super(loanId, "STUDENT", amount, rate, duration, "PENDING", officer, branch);
        this.universityName = universityName;
        this.courseOfStudy = courseOfStudy;
    }

    @Override
    public boolean checkEligibility() {
        // Student loan max amount: 1,000,000
        return getLoanAmount() > 0 && getLoanAmount() <= 1000000 && getInterestRate() >= 2 && getInterestRate() <= 5;
    }

    @Override
    public double calculateInterest() {
        // Student loan: 3% interest rate (subsidized)
        return getLoanAmount() * 0.03;
    }

    @Override
    public double calculateMonthlyInstallment() {
        return calculateTotalRepayment() / getLoanDuration();
    }

    public String getUniversityName() {
        return universityName;
    }

    public void setUniversityName(String universityName) {
        this.universityName = universityName;
    }

    public String getCourseOfStudy() {
        return courseOfStudy;
    }

    public void setCourseOfStudy(String courseOfStudy) {
        this.courseOfStudy = courseOfStudy;
    }

    @Override
    public String toString() {
        return super.toString() + ", University: " + universityName + ", Course: " + courseOfStudy;
    }
}
