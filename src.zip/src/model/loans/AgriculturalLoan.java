package src.model.loans;

import src.service.LoanManager;

/**
 * AgriculturalLoan class represents an agricultural/farm loan product.
 * Extends LoanManager with agricultural loan specific attributes and behavior.
 */
public class AgriculturalLoan extends LoanManager {

    private double farmSize; // in hectares
    private String cropType;

    /**
     * Constructor for AgriculturalLoan
     */
    public AgriculturalLoan(String loanId, double amount, double rate, int duration,
                            String officer, String branch, String cropType) {
        super(loanId, "AGRICULTURAL", amount, rate, duration, "PENDING", officer, branch);
        this.cropType = cropType;
        this.farmSize = 0; // Default farm size
    }

    /**
     * Overloaded constructor with farm size
     */
    public AgriculturalLoan(String loanId, double amount, double rate, int duration,
                            String officer, String branch, String cropType, double farmSize) {
        super(loanId, "AGRICULTURAL", amount, rate, duration, "PENDING", officer, branch);
        this.cropType = cropType;
        this.farmSize = farmSize;
    }

    @Override
    public boolean checkEligibility() {
        // Agricultural loan max amount: 3,000,000
        return getLoanAmount() > 0 && getLoanAmount() <= 3000000 && getInterestRate() >= 2 && getInterestRate() <= 6;
    }

    @Override
    public double calculateInterest() {
        // Agricultural loan: 4% interest rate (seasonal subsidy)
        return getLoanAmount() * 0.04;
    }

    @Override
    public double calculateMonthlyInstallment() {
        return calculateTotalRepayment() / getLoanDuration();
    }

    public double getFarmSize() {
        return farmSize;
    }

    public void setFarmSize(double farmSize) {
        this.farmSize = farmSize;
    }

    public String getCropType() {
        return cropType;
    }

    public void setCropType(String cropType) {
        this.cropType = cropType;
    }

    @Override
    public String toString() {
        return super.toString() + ", Farm Size: " + farmSize + " hectares, Crop Type: " + cropType;
    }
}
