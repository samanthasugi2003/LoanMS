package src.model.loans;

import src.service.LoanManager;

/**
 * HomeLoan class represents a home/mortgage loan product.
 * Extends LoanManager with home loan specific attributes and behavior.
 */
public class HomeLoan extends LoanManager {

    private String propertyLocation;
    private double propertyValue;

    /**
     * Constructor for HomeLoan
     */
    public HomeLoan(String loanId, double amount, double rate, int duration,
                    String officer, String branch, String propertyLocation) {
        super(loanId, "HOME", amount, rate, duration, "PENDING", officer, branch);
        this.propertyLocation = propertyLocation;
        this.propertyValue = amount * 1.2; // Estimated property value
    }

    @Override
    public boolean checkEligibility() {
        // Home loan max amount: 5,000,000
        return getLoanAmount() > 0 && getLoanAmount() <= 5000000 && getInterestRate() >= 3 && getInterestRate() <= 8;
    }

    @Override
    public double calculateInterest() {
        // Home loan: 5% interest rate
        return getLoanAmount() * 0.05;
    }

    @Override
    public double calculateMonthlyInstallment() {
        return calculateTotalRepayment() / getLoanDuration();
    }

    public String getPropertyLocation() {
        return propertyLocation;
    }

    public void setPropertyLocation(String propertyLocation) {
        this.propertyLocation = propertyLocation;
    }

    public double getPropertyValue() {
        return propertyValue;
    }

    public void setPropertyValue(double propertyValue) {
        this.propertyValue = propertyValue;
    }

    @Override
    public String toString() {
        return super.toString() + ", Property Location: " + propertyLocation + ", Property Value: " + propertyValue;
    }
}
