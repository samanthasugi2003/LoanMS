package src.model.loans;

import src.service.LoanManager;

/**
 * PersonalLoan class represents a personal loan product.
 * Extends LoanManager with personal loan specific attributes and behavior.
 */
public class PersonalLoan extends LoanManager {

    private String purpose;

    /**
     * Constructor for PersonalLoan
     */
    public PersonalLoan(String loanId, double amount, double rate, int duration,
                        String officer, String branch, String purpose) {
        super(loanId, "PERSONAL", amount, rate, duration, "PENDING", officer, branch);
        this.purpose = purpose;
    }

    @Override
    public boolean checkEligibility() {
        // Personal loan max amount: 50,000
        return getLoanAmount() > 0 && getLoanAmount() <= 50000 && getInterestRate() >= 5 && getInterestRate() <= 15;
    }

    @Override
    public double calculateInterest() {
        // Personal loan: 10% interest rate
        return getLoanAmount() * 0.10;
    }

    @Override
    public double calculateMonthlyInstallment() {
        return calculateTotalRepayment() / getLoanDuration();
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    @Override
    public String toString() {
        return super.toString() + ", Purpose: " + purpose;
    }
}