package src.model;

import src.service.LoanManager;

public class Repayment {
    private String paymentId;
    private LoanManager loan;
    private double amountPaid;
    private String paymentDate;
    private double remainingBalance;

    public Repayment() {}

    public Repayment(String paymentId, LoanManager loan, double amountPaid,
                     String paymentDate, double remainingBalance) {
        this.paymentId = paymentId;
        this.loan = loan;
        this.amountPaid = amountPaid;
        this.paymentDate = paymentDate;
        this.remainingBalance = remainingBalance;
    }

    public String getPaymentId() { return paymentId; }
    public void setPaymentId(String paymentId) { this.paymentId = paymentId; }
    public LoanManager getLoan() { return loan; }
    public void setLoan(LoanManager loan) { this.loan = loan; }
    public double getAmountPaid() { return amountPaid; }
    public void setAmountPaid(double amountPaid) { this.amountPaid = amountPaid; }
    public String getPaymentDate() { return paymentDate; }
    public void setPaymentDate(String paymentDate) { this.paymentDate = paymentDate; }
    public double getRemainingBalance() { return remainingBalance; }
    public void setRemainingBalance(double remainingBalance) { this.remainingBalance = remainingBalance; }

    public void updateRemainingBalance() {
        setRemainingBalance(remainingBalance - amountPaid);
    }

    @Override
    public String toString() {
        return "Payment ID: " + paymentId + ", Amount Paid: " + amountPaid +
               ", Date: " + paymentDate + ", Remaining Balance: " + remainingBalance;
    }
}
