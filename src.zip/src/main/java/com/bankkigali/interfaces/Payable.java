package src.interfaces;

/**
 * Payable interface defines the contract for payment processing.
 * Demonstrates interface-based programming and polymorphism.
 */
public interface Payable {

    /**
     * Process a payment for the loan
     * @param amount The payment amount
     */
    void processPayment(double amount);

    /**
     * Calculate remaining balance on the loan
     * @return The remaining balance
     */
    double calculateRemainingBalance();

    /**
     * Generate payment receipt
     * @return Receipt details as string
     */
    String generatePaymentReceipt();
}
