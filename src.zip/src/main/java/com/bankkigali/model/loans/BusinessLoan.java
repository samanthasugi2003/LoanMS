package com.bankkigali.model.loans;

import com.bankkigali.service.LoanManager;

/**
 * BusinessLoan class represents a business loan product.
 * Extends LoanManager with business loan specific attributes and behavior.
 * Demonstrates inheritance and method overriding.
 */
public class BusinessLoan extends LoanManager {

    private String businessName;
    private String industryType;

    /**
     * Constructor for BusinessLoan
     */
    public BusinessLoan(String loanId, double amount, double rate, int duration,
                        String officer, String branch, String businessName) {
        super(loanId, "BUSINESS", amount, rate, duration, "PENDING", officer, branch);
        this.businessName = businessName;
        this.industryType = "General";
    }

    /**
     * Overloaded constructor with industry type
     */
    public BusinessLoan(String loanId, double amount, double rate, int duration,
                        String officer, String branch, String businessName, String industryType) {
        super(loanId, "BUSINESS", amount, rate, duration, "PENDING", officer, branch);
        this.businessName = businessName;
        this.industryType = industryType;
    }

    @Override
    public boolean checkEligibility() {
        // Business loan max amount: 10,000,000
        return getLoanAmount() > 0 && getLoanAmount() <= 10000000 && 
               getInterestRate() >= 4 && getInterestRate() <= 10;
    }

    @Override
    public double calculateInterest() {
        // Business loan: 7% interest rate
        return getLoanAmount() * 0.07;
    }

    @Override
    public double calculateMonthlyInstallment() {
        return calculateTotalRepayment() / getLoanDuration();
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public String getIndustryType() {
        return industryType;
    }

    public void setIndustryType(String industryType) {
        this.industryType = industryType;
    }

    @Override
    public String toString() {
        return super.toString() + "\n  Business Name: " + businessName + 
               ", Industry Type: " + industryType;
    }
}
