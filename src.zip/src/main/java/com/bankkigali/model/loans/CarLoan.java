package com.bankkigali.model.loans;

import com.bankkigali.service.LoanManager;

/**
 * CarLoan class represents a car/auto loan product.
 * Extends LoanManager with car loan specific attributes and behavior.
 * Demonstrates inheritance and method overriding.
 */
public class CarLoan extends LoanManager {

    private String carModel;
    private double carValue;

    /**
     * Constructor for CarLoan
     */
    public CarLoan(String loanId, double amount, double rate, int duration,
                   String officer, String branch, String carModel) {
        super(loanId, "CAR", amount, rate, duration, "PENDING", officer, branch);
        this.carModel = carModel;
        this.carValue = amount * 1.1; // Estimated car value
    }

    @Override
    public boolean checkEligibility() {
        // Car loan max amount: 2,000,000
        return getLoanAmount() > 0 && getLoanAmount() <= 2000000 && 
               getInterestRate() >= 6 && getInterestRate() <= 12;
    }

    @Override
    public double calculateInterest() {
        // Car loan: 8% interest rate
        return getLoanAmount() * 0.08;
    }

    @Override
    public double calculateMonthlyInstallment() {
        return calculateTotalRepayment() / getLoanDuration();
    }

    public String getCarModel() {
        return carModel;
    }

    public void setCarModel(String carModel) {
        this.carModel = carModel;
    }

    public double getCarValue() {
        return carValue;
    }

    public void setCarValue(double carValue) {
        this.carValue = carValue;
    }

    @Override
    public String toString() {
        return super.toString() + "\n  Car Model: " + carModel + 
               ", Estimated Value: " + String.format("%.2f", carValue);
    }
}
