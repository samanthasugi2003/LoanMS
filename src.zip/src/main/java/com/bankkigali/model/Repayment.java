package com.bankkigali.model;

import com.bankkigali.service.LoanManager;

/**
 * Repayment class tracks payment information for loans.
 * Encapsulates repayment details and balance tracking.
 */
public class Repayment {
    private String paymentId;
    private LoanManager loan;
    private double amountPaid;
    private String paymentDate;
    private double remainingBalance;

    /**
     * Default Constructor
     */
    public Repayment() {}

    /**
     * Parameterized Constructor
     */
    public Repayment(String paymentId, LoanManager loan, double amountPaid,
                     String paymentDate, double remainingBalance) {
        this.paymentId = paymentId;
        this.loan = loan;
        this.amountPaid = amountPaid;
        this.paymentDate = paymentDate;
        this.remainingBalance = remainingBalance;
    }

    // ==================== GETTERS & SETTERS ====================

    public String getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(String paymentId) {
        this.paymentId = paymentId;
    }

    public LoanManager getLoan() {
        return loan;
    }

    public void setLoan(LoanManager loan) {
        this.loan = loan;
    }

    public double getAmountPaid() {
        return amountPaid;
    }

    public void setAmountPaid(double amountPaid) {
        this.amountPaid = amountPaid;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    public double getRemainingBalance() {
        return remainingBalance;
    }

    public void setRemainingBalance(double remainingBalance) {
        this.remainingBalance = remainingBalance;
    }

    /**
     * Update remaining balance after payment
     */
    public void updateRemainingBalance() {
        this.remainingBalance = this.remainingBalance - this.amountPaid;
    }

    // ==================== TOSTRING ====================

    @Override
    public String toString() {
        return "Payment ID: " + paymentId + ", Amount Paid: " + amountPaid +
               ", Date: " + paymentDate + ", Remaining Balance: " + String.format("%.2f", remainingBalance);
    }
}
