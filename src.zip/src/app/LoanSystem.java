package src.app;

import java.util.Scanner;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import src.model.Customer;
import src.model.Repayment;
import src.service.LoanFactory;
import src.service.LoanManager;
import src.util.InputValidator;

/**
 * LoanSystem is the main entry point for the Bank of Kigali Loan Management System.
 * This class orchestrates user interactions, validates inputs, and manages the loan workflow.
 */
public class LoanSystem {
    private static final Scanner scanner = new Scanner(System.in);
    private static final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public static void main(String[] args) {
        try {
            System.out.println("\n===== Bank of Kigali Loan Management System =====\n");

            // ==================== CUSTOMER INPUT ====================
            Customer customer = inputCustomerDetails();
            System.out.println("\n✓ Customer registered successfully!");
            System.out.println(customer);

            // ==================== LOAN INPUT ====================
            LoanManager loan = inputLoanDetails();
            System.out.println("\n✓ Loan application created!");
            System.out.println(loan);

            // ==================== LOAN ELIGIBILITY CHECK ====================
            System.out.println("\n--- Checking Loan Eligibility ---");
            if (loan.checkEligibility()) {
                System.out.println("✓ Customer is ELIGIBLE for this loan!");
                loan.approveLoan();
            } else {
                System.out.println("✗ Customer is NOT ELIGIBLE for this loan.");
                loan.rejectLoan();
                return;
            }

            // ==================== LOAN DETAILS ====================
            System.out.println("\n--- Loan Summary ---");
            System.out.println("Loan Status: " + loan.getLoanStatus());
            System.out.println("Loan Amount: " + loan.getLoanAmount());
            System.out.println("Interest Rate: " + loan.getInterestRate() + "%");
            System.out.println("Total Interest: " + String.format("%.2f", loan.calculateInterest()));
            System.out.println("Total Repayment: " + String.format("%.2f", loan.calculateTotalRepayment()));
            System.out.println("Monthly Installment: " + String.format("%.2f", loan.calculateMonthlyInstallment()));
            System.out.println("Loan Duration: " + loan.getLoanDuration() + " months");

            // ==================== PAYMENT PROCESSING ====================
            System.out.println("\n--- Payment Processing ---");
            processPayment(customer, loan);

            // ==================== LOAN REPORT ====================
            System.out.println("\n--- Final Loan Report ---");
            System.out.println(loan.generateLoanReport());

            System.out.println("\n===== Thank you for using Bank of Kigali Loan Management System =====\n");

        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }

    /**
     * Collects and validates customer details from user input
     */
    private static Customer inputCustomerDetails() {
        String customerId;
        String customerName;
        String nationalId;
        String phoneNumber;

        // Customer ID
        System.out.print("Enter Customer ID: ");
        customerId = scanner.nextLine();
        while (InputValidator.isEmptyString(customerId)) {
            System.out.print("Customer ID cannot be empty. Try again: ");
            customerId = scanner.nextLine();
        }

        // Customer Name
        System.out.print("Enter Customer Name: ");
        customerName = scanner.nextLine();
        while (InputValidator.isEmptyString(customerName)) {
            System.out.print("Customer Name cannot be empty. Try again: ");
            customerName = scanner.nextLine();
        }

        // National ID
        System.out.print("Enter National ID (16 characters): ");
        nationalId = scanner.nextLine();
        while (!InputValidator.isValidNationalId(nationalId)) {
            System.out.print("Invalid National ID. Must be 16 alphanumeric characters. Try again: ");
            nationalId = scanner.nextLine();
        }

        // Phone Number
        System.out.print("Enter Phone Number (10 digits): ");
        phoneNumber = scanner.nextLine();
        while (!InputValidator.isValidPhoneNumber(phoneNumber)) {
            System.out.print("Invalid Phone Number. Must be 10 digits (e.g., 0788123456). Try again: ");
            phoneNumber = scanner.nextLine();
        }

        return new Customer(customerId, customerName, nationalId, phoneNumber);
    }

    /**
     * Collects and validates loan details from user input
     */
    private static LoanManager inputLoanDetails() {
        String loanId;
        String loanType;
        double loanAmount;
        double interestRate;
        int loanDuration;
        String officerName;
        String branchLocation;
        String specificAttribute;

        // Loan ID
        System.out.print("\nEnter Loan ID: ");
        loanId = scanner.nextLine();
        while (InputValidator.isEmptyString(loanId)) {
            System.out.print("Loan ID cannot be empty. Try again: ");
            loanId = scanner.nextLine();
        }

        // Loan Type
        System.out.print("Enter Loan Type (PERSONAL/HOME/CAR/BUSINESS/STUDENT/AGRICULTURAL): ");
        loanType = scanner.nextLine();
        while (!InputValidator.isValidLoanType(loanType)) {
            System.out.print("Invalid Loan Type. Please choose from: PERSONAL, HOME, CAR, BUSINESS, STUDENT, AGRICULTURAL: ");
            loanType = scanner.nextLine();
        }

        // Loan Amount
        System.out.print("Enter Loan Amount: ");
        String amountInput = scanner.nextLine();
        while (!InputValidator.isValidDouble(amountInput)) {
            System.out.print("Invalid amount. Please enter a valid number: ");
            amountInput = scanner.nextLine();
        }
        loanAmount = Double.parseDouble(amountInput);
        while (!InputValidator.isValidLoanAmount(loanAmount)) {
            System.out.print("Invalid loan amount. Must be between 0 and 100,000,000: ");
            amountInput = scanner.nextLine();
            while (!InputValidator.isValidDouble(amountInput)) {
                System.out.print("Invalid amount. Please enter a valid number: ");
                amountInput = scanner.nextLine();
            }
            loanAmount = Double.parseDouble(amountInput);
        }

        // Interest Rate
        System.out.print("Enter Interest Rate (%): ");
        String rateInput = scanner.nextLine();
        while (!InputValidator.isValidDouble(rateInput)) {
            System.out.print("Invalid rate. Please enter a valid number: ");
            rateInput = scanner.nextLine();
        }
        interestRate = Double.parseDouble(rateInput);
        while (!InputValidator.isValidInterestRate(interestRate)) {
            System.out.print("Invalid interest rate. Must be between 0% and 50%: ");
            rateInput = scanner.nextLine();
            while (!InputValidator.isValidDouble(rateInput)) {
                System.out.print("Invalid rate. Please enter a valid number: ");
                rateInput = scanner.nextLine();
            }
            interestRate = Double.parseDouble(rateInput);
        }

        // Loan Duration
        System.out.print("Enter Loan Duration (months): ");
        String durationInput = scanner.nextLine();
        while (!InputValidator.isValidInteger(durationInput)) {
            System.out.print("Invalid duration. Please enter a valid integer: ");
            durationInput = scanner.nextLine();
        }
        loanDuration = Integer.parseInt(durationInput);
        while (!InputValidator.isValidLoanDuration(loanDuration)) {
            System.out.print("Invalid duration. Must be between 1 and 360 months: ");
            durationInput = scanner.nextLine();
            while (!InputValidator.isValidInteger(durationInput)) {
                System.out.print("Invalid duration. Please enter a valid integer: ");
                durationInput = scanner.nextLine();
            }
            loanDuration = Integer.parseInt(durationInput);
        }

        // Officer Name
        System.out.print("Enter Loan Officer Name: ");
        officerName = scanner.nextLine();
        while (InputValidator.isEmptyString(officerName)) {
            System.out.print("Officer Name cannot be empty. Try again: ");
            officerName = scanner.nextLine();
        }

        // Branch Location
        System.out.print("Enter Branch Location: ");
        branchLocation = scanner.nextLine();
        while (InputValidator.isEmptyString(branchLocation)) {
            System.out.print("Branch Location cannot be empty. Try again: ");
            branchLocation = scanner.nextLine();
        }

        // Type-specific attribute
        specificAttribute = inputTypeSpecificAttribute(loanType);

        // Use Factory pattern to create loan
        return LoanFactory.createLoan(loanType, loanId, loanAmount, interestRate, loanDuration, officerName, branchLocation, specificAttribute);
    }

    /**
     * Collects type-specific attribute based on loan type
     */
    private static String inputTypeSpecificAttribute(String loanType) {
        String loanTypeUpper = loanType.toUpperCase();

        switch (loanTypeUpper) {
            case "PERSONAL":
                System.out.print("Enter Purpose of Loan: ");
                return scanner.nextLine();
            case "HOME":
                System.out.print("Enter Property Location: ");
                return scanner.nextLine();
            case "CAR":
                System.out.print("Enter Car Model: ");
                return scanner.nextLine();
            case "BUSINESS":
                System.out.print("Enter Business Name: ");
                return scanner.nextLine();
            case "STUDENT":
                System.out.print("Enter University Name: ");
                return scanner.nextLine();
            case "AGRICULTURAL":
                System.out.print("Enter Crop Type: ");
                return scanner.nextLine();
            default:
                return "";
        }
    }

    /**
     * Processes a payment for the loan
     */
    private static void processPayment(Customer customer, LoanManager loan) {
        System.out.print("Enter Payment Amount: ");
        String paymentInput = scanner.nextLine();
        
        while (!InputValidator.isValidDouble(paymentInput)) {
            System.out.print("Invalid amount. Please enter a valid number: ");
            paymentInput = scanner.nextLine();
        }

        double paymentAmount = Double.parseDouble(paymentInput);
        
        while (!InputValidator.isNonNegative(paymentAmount)) {
            System.out.print("Invalid amount. Payment must be positive: ");
            paymentInput = scanner.nextLine();
            while (!InputValidator.isValidDouble(paymentInput)) {
                System.out.print("Invalid amount. Please enter a valid number: ");
                paymentInput = scanner.nextLine();
            }
            paymentAmount = Double.parseDouble(paymentInput);
        }

        // Process payment
        loan.processPayment(paymentAmount);

        // Create repayment record
        String paymentId = "PAY-" + System.currentTimeMillis();
        String paymentDate = LocalDate.now().format(dateFormatter);
        double remainingBalance = loan.calculateRemainingBalance();

        Repayment repayment = new Repayment(paymentId, loan, paymentAmount, paymentDate, remainingBalance);

        System.out.println("\n--- Payment Receipt ---");
        System.out.println(repayment);
        System.out.println("Payment Status: " + loan.generatePaymentReceipt());
    }
}
            String loanType = scanner.nextLine();
            while (InputValidator.isEmptyString(loanType)) {
                System.out.println("Loan Type cannot be empty. Try again: ");
                loanType = scanner.nextLine();
            }

            // Unique attributes per loan type
            String businessType = "";
            String vehicleModel = "";
            String universityName = "";
            double propertyValue = 0;
            double farmSize = 0;
            int creditScore = 0;

            if (loanType.equalsIgnoreCase("Business")) {
                System.out.println("Enter Business Type: ");
                businessType = scanner.nextLine();
            } else if (loanType.equalsIgnoreCase("Car")) {
                System.out.println("Enter Vehicle Model: ");
                vehicleModel = scanner.nextLine();
            } else if (loanType.equalsIgnoreCase("Student")) {
                System.out.println("Enter University Name: ");
                universityName = scanner.nextLine();
            } else if (loanType.equalsIgnoreCase("Home")) {
                System.out.println("Enter Property Value: ");
                propertyValue = scanner.nextDouble();
                scanner.nextLine();
            } else if (loanType.equalsIgnoreCase("Agricultural")) {
                System.out.println("Enter Farm Size (hectares): ");
                farmSize = scanner.nextDouble();
                scanner.nextLine();
            } else if (loanType.equalsIgnoreCase("Personal")) {
                System.out.println("Enter Credit Score: ");
                creditScore = scanner.nextInt();
                scanner.nextLine();
            }

            System.out.println("Enter Loan Amount: ");
            double loanAmount = scanner.nextDouble();
            while (!InputValidator.isValidAmount(loanAmount)) {
                System.out.println("Invalid amount. Must be greater than 0. Try again: ");
                loanAmount = scanner.nextDouble();
            }

            System.out.println("Enter Interest Rate: ");
            double interestRate = scanner.nextDouble();
            while (!InputValidator.isValidInterestRate(interestRate)) {
                System.out.println("Invalid interest rate. Must be between 0 and 100. Try again: ");
                interestRate = scanner.nextDouble();
            }

            System.out.println("Enter Loan Duration (months): ");
            int loanDuration = scanner.nextInt();
            while (!InputValidator.isValidDuration(loanDuration)) {
                System.out.println("Invalid duration. Must be greater than 0. Try again: ");
                loanDuration = scanner.nextInt();
            }
            scanner.nextLine();

            System.out.println("Enter Officer Name: ");
            String officerName = scanner.nextLine();

            System.out.println("Enter Branch Location: ");
            String branchLocation = scanner.nextLine();

            // Create loan using factory
            LoanManager loan = LoanFactory.createLoan(loanType, loanId, loanAmount,
                               interestRate, loanDuration, officerName, branchLocation);

            // Check for invalid loan type
            if (loan == null) {
                System.out.println("Could not create loan. Invalid loan type.");
                return;
            }

            // Set unique attributes
            if (loanType.equalsIgnoreCase("Business")) {
                ((BusinessLoan) loan).setBusinessType(businessType);
            } else if (loanType.equalsIgnoreCase("Car")) {
                ((CarLoan) loan).setVehicleModel(vehicleModel);
            } else if (loanType.equalsIgnoreCase("Student")) {
                ((StudentLoan) loan).setUniversityName(universityName);
            } else if (loanType.equalsIgnoreCase("Home")) {
                ((HomeLoan) loan).setPropertyValue(propertyValue);
            } else if (loanType.equalsIgnoreCase("Agricultural")) {
                ((AgriculturalLoan) loan).setFarmSize(farmSize);
            } else if (loanType.equalsIgnoreCase("Personal")) {
                ((PersonalLoan) loan).setCreditScore(creditScore);
            }

            // Check eligibility and approve or reject
            if (loan.checkEligibility()) {
                loan.approveLoan();
            } else {
                loan.rejectLoan();
            }

            // Display customer and loan details
            System.out.println("\n===== Customer Details =====");
            System.out.println(customer);

            System.out.println("\n===== Loan Details =====");
            loan.generateLoanReport();

            // Process payment
            System.out.println("\nEnter Payment Amount: ");
            double paymentAmount = scanner.nextDouble();
            while (!InputValidator.isValidAmount(paymentAmount)) {
                System.out.println("Invalid amount. Try again: ");
                paymentAmount = scanner.nextDouble();
            }

            loan.processPayment(paymentAmount);

            // Calculate correct remaining balance
            double remainingAfterPayment = loan.calculateTotalRepayment() - paymentAmount;

            Repayment repayment = new Repayment("PAY-001", loan, paymentAmount,
                                                 "2024-01-01", remainingAfterPayment);

            // Display repayment summary
            System.out.println("\n===== Repayment Summary =====");
            System.out.println(repayment);
            loan.generatePaymentReceipt(remainingAfterPayment);
        }
    }
}
