package src.service;

import src.model.loans.*;

/**
 * LoanFactory class demonstrates the Factory pattern and polymorphism.
 * Creates appropriate loan objects based on the specified loan type.
 */
public class LoanFactory {

    /**
     * Creates and returns a LoanManager object based on the loan type
     * 
     * @param loanType Type of loan (PERSONAL, HOME, CAR, BUSINESS, STUDENT, AGRICULTURAL)
     * @param loanId Unique identifier for the loan
     * @param amount Loan amount
     * @param rate Interest rate
     * @param duration Loan duration in months
     * @param officer Loan officer name
     * @param branch Branch location
     * @param specificAttribute Type-specific attribute (purpose, property value, etc.)
     * @return LoanManager object of appropriate subclass
     */
    public static LoanManager createLoan(String loanType, String loanId, double amount,
                                         double rate, int duration, String officer,
                                         String branch, String specificAttribute) {
        String type = loanType.toUpperCase();

        switch (type) {
            case "PERSONAL":
                return new PersonalLoan(loanId, amount, rate, duration, officer, branch, specificAttribute);
            case "HOME":
                return new HomeLoan(loanId, amount, rate, duration, officer, branch, specificAttribute);
            case "CAR":
                return new CarLoan(loanId, amount, rate, duration, officer, branch, specificAttribute);
            case "BUSINESS":
                return new BusinessLoan(loanId, amount, rate, duration, officer, branch, specificAttribute);
            case "STUDENT":
                return new StudentLoan(loanId, amount, rate, duration, officer, branch, specificAttribute);
            case "AGRICULTURAL":
                return new AgriculturalLoan(loanId, amount, rate, duration, officer, branch, specificAttribute);
            default:
                throw new IllegalArgumentException("Invalid loan type: " + loanType);
        }
    }
}
