package src.service;

import src.model.Loan;
import src.interfaces.Payable;

public class LoanManager extends Loan implements Payable {

    private String officerName;
    private String branchLocation;
    private double remainingBalance;

    public LoanManager() {}

    public LoanManager(String loanId, String loanType, double loanAmount,
                       double interestRate, int loanDuration, String loanStatus,
                       String officerName, String branchLocation) {

        super(loanId, loanType, loanAmount, interestRate, loanDuration, loanStatus);
        this.officerName = officerName;
        this.branchLocation = branchLocation;
        this.remainingBalance = loanAmount;
    }

    // ================= ABSTRACT METHODS =================

    @Override
    public double calculateInterest() {
        return getLoanAmount() * getInterestRate() / 100;
    }

    @Override
    public double calculateMonthlyInstallment() {
        return calculateTotalRepayment() / getLoanDuration();
    }

    @Override
    public boolean checkEligibility() {
        return getLoanAmount() > 0 && getInterestRate() > 0;
    }

    @Override
    public void approveLoan() {
        setLoanStatus("APPROVED");
    }

    @Override
    public void rejectLoan() {
        setLoanStatus("REJECTED");
    }

    @Override
    public double calculateTotalRepayment() {
        return getLoanAmount() + calculateInterest();
    }

    @Override
    public String generateLoanReport() {
        return toString() + ", Remaining Balance: " + remainingBalance;
    }

    @Override
    public boolean validateLoanDetails() {
        return getLoanAmount() > 0 && getLoanDuration() > 0;
    }

    // ================= INTERFACE METHODS =================

    @Override
    public void processPayment(double amount) {
        remainingBalance -= amount;
    }

    @Override
    public double calculateRemainingBalance() {
        return remainingBalance;
    }

    @Override
    public String generatePaymentReceipt() {
        return "Payment processed. Remaining: " + remainingBalance;
    }

    // ================= GETTERS & SETTERS =================

    public String getOfficerName() {
        return officerName;
    }

    public void setOfficerName(String officerName) {
        this.officerName = officerName;
    }

    public String getBranchLocation() {
        return branchLocation;
    }

    public void setBranchLocation(String branchLocation) {
        this.branchLocation = branchLocation;
    }

    public double getRemainingBalance() {
        return remainingBalance;
    }

    public void setRemainingBalance(double remainingBalance) {
        this.remainingBalance = remainingBalance;
    }

    // ================= TOSTRING =================

    @Override
    public String toString() {
        return super.toString() + ", Officer: " + officerName + ", Branch: " + branchLocation +
               ", Monthly Installment: " + calculateMonthlyInstallment();
    }
}